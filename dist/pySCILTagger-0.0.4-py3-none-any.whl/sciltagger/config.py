model_location = {
        "MODEL" : "/.pySCIL-Tagger/models",
        "label_mapping" : "/label_map.txt"
    }

model_download_link = {
        "selected.pt" : "https://www.dropbox.com/s/0rfyb2h0brezea4/selected.pt?dl=1"
    }