# pySCIL-Tagger
Tagger for SCIL

Usage can be seen in tagger/test.py

More documentation to be added later. This is a WIP.
